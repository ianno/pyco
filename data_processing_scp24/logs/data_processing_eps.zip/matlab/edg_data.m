iter = 10000;
load('EDG_SINGLE_PLAIN');
load('EDG_PAR_PLAIN');
load('EDG_PAR_PORTS');
load('EDG_PAR_COMPS');

figure;
hold;
stat = bootstrp(iter, @mean, EDG_SINGLE_PLAIN);
histogram(stat);
stat = bootstrp(iter, @mean, EDG_PAR_PLAIN);
histogram(stat);
stat = bootstrp(iter, @mean, EDG_PAR_PORTS);
histogram(stat);
stat = bootstrp(iter, @mean, EDG_PAR_COMPS);
histogram(stat);

mean_edg_single = mean(EDG_SINGLE_PLAIN)
mean_edg_plain = mean(EDG_PAR_PLAIN)
mean_edg_ports = mean(EDG_PAR_PORTS)
mean_edg_comps = mean(EDG_PAR_COMPS)
meanci_edg_single = bootci(iter, @mean, EDG_SINGLE_PLAIN)
meanci_edg_plain = bootci(iter, @mean, EDG_PAR_PLAIN)
meanci_edg_ports = bootci(iter, @mean, EDG_PAR_PORTS)
meanci_edg_comps = bootci(iter, @mean, EDG_PAR_COMPS)

%median is very bad
figure;
hold;
stat = bootstrp(iter, @median, EDG_SINGLE_PLAIN);
histogram(stat);
stat = bootstrp(iter, @median, EDG_PAR_PLAIN);
histogram(stat);
stat = bootstrp(iter, @median, EDG_PAR_PORTS);
histogram(stat);
stat = bootstrp(iter, @median, EDG_PAR_COMPS);
histogram(stat);


med_edg_single = bootci(iter, @median, EDG_SINGLE_PLAIN);
med_edg_plain = bootci(iter, @median, EDG_PAR_PLAIN);
med_edg_ports = bootci(iter, @median, EDG_PAR_PORTS);
med_edg_comps = bootci(iter, @mean, EDG_PAR_COMPS);